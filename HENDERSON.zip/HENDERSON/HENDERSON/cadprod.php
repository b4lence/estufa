<?php
session_start();
if (!isset($_SESSION['user'])){
	header('Location: cadlogin.php');
	exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="_css/prodstyle.css">
    <link rel="shortcut icon" href="favicon.ico">
    <title>Cadastro - Produto</title>
</head>

<body>
    <div class="container">
        <div class="form-image">
        <img src="_images/cadprod-animate.svg" alt="Animação de segurança">
        </div>
        <div class="form">
            <form class="form-prod" action="_php/cad-produto.php" method="post">
                <div class="form-header">
                    <div class="title">
                        <h1>Produto</h1>
                    </div>
                </div>

                <div class="input-group">

                    <div class="input-box">
                        <label for="nome-produto">Nome do produto</label>
                        <input id="nome-produto" type="text" name="nomeprod" placeholder="Digite o nome do produto"
                            required>
                    </div>
                    <div class="input-box">
                        <label for="firstname">Quantidade</label>
                        <input min="0" type="number" name="quantidade" id="quantidade" placeholder="Digite a quantidade de produtos" required>

                    </div>
                    <div class="input-box">
                        <label for="unidade">Unidade de medida</label>
                        <select id="unidade" name="unidade">
                            <option value="Outros">Selecione uma unidade:</option>
                            <option value="Kg">Quilograma(Kg)</option>
                            <option value="m">Metro(m)</option>
                            <option value="L">Litro(L)</option>
                            <option value="Outros">Outros</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <label for="preco">Preço</label>
                        <input type="text" id="precoVisual" oninput="mascaraMoeda(event)" placeholder="R$:00,00"/>
                        <input type="hidden" id="preco" name="preco" />

                    </div>
                    <div class="input-box">
                        <label for="descricao">Descrição</label>
                        <textarea name="descricao" id="descricao" cols="320" rows="10" placeholder="Insira sua descrição..." required></textarea>
                    </div>
                </div>
                <div class="continue-button">
                    <input type="submit" value="Cadastrar">
                </div>
            </form>
        </div>
    </div>
    <script src="_js/scriptprod.js"></script>
</body>

</html>