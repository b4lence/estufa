<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="_css/loginstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Login</title>
</head>

<body>
    <div class="container">
        <div class="form-image">
            <img src="_images/login-animate.svg" alt="Animação de segurança">
        </div>
        <div class="form">
            <form action="_php/login.php" method="post">
                <div class="form-header">
                    <div class="title">
                        <h1>Entrar</h1>
                    </div>
                </div>

                <div class="input-group">
                    <div class="input-box">
                        <label for="user">Usuário</label>
                        <input id="user" type="text" name="user" placeholder="Insira seu nome de usuário" required>
                    </div>

                    <div class="input-box">
                        <label for="password">Senha</label>
                        <input id="password" type="password" name="password" placeholder="Digite sua senha" required>
                    </div>
                </div>

                <div class="social-login">
                    <p>Entre com</p>
                    <div class="social-buttons">
                        <a href="#" class="social-button google">
                            <i class="fab fa-google"></i>
                            Google
                        </a>
                        <a href="#" class="social-button facebook">
                            <i class="fab fa-facebook-f"></i>
                            Facebook
                        </a>
                        <a href="#" class="social-button instagram">
                            <i class="fab fa-instagram"></i>
                            Instagram
                        </a>
                    </div>
                </div>

                <div class="continue-button">
                    <input type="submit" value="Entrar">
                </div>
            </form>
        </div>
    </div>
</body>

</html>
