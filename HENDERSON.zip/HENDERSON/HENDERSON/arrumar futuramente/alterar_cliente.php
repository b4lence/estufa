<?php
require "_connection/conexao.php";

function consultar_cliente($nome){
    $conexao = new Conexao();
    if(empty($nome)){
        return;
    }
    $nome = '%'.$nome.'%';
    $conn = $conexao->conectar();
    $sql = "SELECT * FROM clientes WHERE nome LIKE ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $nome);
    $stmt->execute();

    $result = $stmt->get_result();
    $table = '<table>';
    $table .= '<thead>';
    $table .= '<tr>';
    $table .= '<td></td>';
    $table .= '<td>Nome</td>';
    $table .= '<td>Sobrenome</td>';
    $table .= '<td>E-mail</td>';
    $table .= '<td>CNPJ</td>';
    $table .= '<td>Telefone</td>';
    $table .= '<td>Endereço</td>';
    $table .= '<td>Empresa</td>';
    $table .= '</tr>';
    $table .= '</thead>';
    
    $clientes = $result->fetch_all();

    $table .= '<tbody>';
    foreach($clientes as $cliente){
        $table .= "<tr>";
        $table .= "<td><input type='radio' name='id' value='{$cliente[0]}'></td>";
        $table .= "<td>{$cliente[1]}</td>";
        $table .= "<td>{$cliente[2]}</td>";
        $table .= "<td>{$cliente[3]}</td>";
        $table .= "<td>{$cliente[4]}</td>";
        $table .= "<td>{$cliente[5]}</td>";
        $table .= "<td>{$cliente[6]}</td>";
        $table .= "<td>{$cliente[7]}</td>";
        $table .= "</tr>";
    }
    $table .= '</tbody>';
    $table .= '</table>';

    $conn->close();
    return $table;
}
function alterar_cliente($id, $nome, $sobrenome, $email, $cnpj, $tel, $endereco, $empresa){
    $conexao = new Conexao();

    $conn = $conexao->conectar();
    $sql = "UPDATE clientes SET nome = ?, sobrenome = ?, email = ?, cnpj = ?, telefone = ?, endereco = ?, empresa = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("sssssssi", $nome, $sobrenome, $email, $cnpj, $tel, $endereco, $empresa, $id);
    $stmt->execute();
}