// jQuery(document).ready(function($){
//     $("a").click(function(event){
//         link=$(this).attr("href");
//         $.ajax({
//             url: link,
//         })
//         .done(function(php){
//             $("#page").empty().append(php);
//         })
//         .fail(function(){
//             console.log("error");
//         })
//         .always(function(){
//             console.log("complete");
//         })
//         return false;
//     })
// })
