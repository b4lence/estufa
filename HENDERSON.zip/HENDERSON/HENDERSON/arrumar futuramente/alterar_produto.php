<?php
require "_connection/conexao.php";

function consultar_produto($nome){
    $conexao = new Conexao();
    if(empty($nome)){
        return;
    }
    $nome = '%'.$nome.'%';
    $conn = $conexao->conectar();
    $sql = "SELECT * FROM produtos WHERE nome LIKE ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $nome);
    $stmt->execute();

    $result = $stmt->get_result();
    $table = '<table>';
    $table .= '<thead>';
    $table .= '<tr>';
    $table .= '<td></td>';
    $table .= '<td>Nome</td>';
    $table .= '<td>Descrição</td>';
    $table .= '<td>Preço</td>';
    $table .= '<td>Estoque</td>';
    $table .= '<td>Unidade</td>';
    $table .= '</tr>';
    $table .= '</thead>';
    
    $produtos = $result->fetch_all();

    $table .= '<tbody>';
    foreach($produtos as $produto){
        $table .= "<tr>";
        $table .= "<td><input type='radio' name='id' value='{$produto[0]}'></td>";
        $table .= "<td>{$produto[1]}</td>";
        $table .= "<td>{$produto[2]}</td>";
        $table .= "<td>{$produto[3]}</td>";
        $table .= "<td>{$produto[4]}</td>";
        $table .= "<td>{$produto[5]}</td>";
        $table .= "</tr>";
    }
    $table .= '</tbody>';
    $table .= '</table>';

    $conn->close();
    return $table;
}
function alterar_produto($id, $nome, $descr, $preco, $unidade, $estoque){
    $conexao = new Conexao();

    $conn = $conexao->conectar();
    $sql = "UPDATE produtos SET nome = ?, descr = ?, estoque = ?, preco = ?, unidade = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ssidsi", $nome, $descr, $estoque, $preco, $unidade, $id);
    $stmt->execute();
}