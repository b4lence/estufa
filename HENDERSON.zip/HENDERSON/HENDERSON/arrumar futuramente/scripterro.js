// Espera até que o conteúdo da página tenha sido completamente carregado
document.addEventListener('DOMContentLoaded', function () {
    // Cria um objeto URLSearchParams com os parâmetros da URL atual
    const urlParams = new URLSearchParams(window.location.search);
    // Obtém o valor do parâmetro 'error' da URL
    const error = urlParams.get('error');
    // Seleciona o elemento HTML com o ID 'mensagemErro'
    const errorDiv = document.getElementById('mensagemErro');
  
    // Verifica se o valor do parâmetro 'error' é 'incorrect'
    if (error === 'incorrect') {
      // Se for, define o texto do elemento 'mensagemErro' para 'Nome de usuário ou senha incorretos!'
      errorDiv.textContent = 'Nome de usuário ou senha incorretos!';
    // Verifica se o valor do parâmetro 'error' é 'exists'
    } else if (error === 'exists') {
      // Se for, define o texto do elemento 'mensagemErro' para 'Usuário já está cadastrado!"
      errorDiv.textContent = 'Usuário já está cadastrado!';
    }
  });