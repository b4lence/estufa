<?php
require "_connection/conexao.php";

function consultar_login($nome){
    $conexao = new Conexao();
    if(empty($nome)){
        return;
    }
    $nome = '%'.$nome.'%';
    $conn = $conexao->conectar();
    $sql = "SELECT * FROM usuarios WHERE nome LIKE ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $nome);
    $stmt->execute();

    $result = $stmt->get_result();
    $table = '<table>';
    $table .= '<thead>';
    $table .= '<tr>';
    $table .= '<td></td>';
    $table .= '<td>Nome</td>';
    $table .= '<td>Senha</td>';
    $table .= '</tr>';
    $table .= '</thead>';
    
    $usuarios = $result->fetch_all();

    $table .= '<tbody>';
    foreach($usuarios as $usuario){
        $table .= "<tr>";
        $table .= "<td><input type='radio' name='id' value='{$usuario[0]}'></td>";
        $table .= "<td>{$usuario[1]}</td>";
        $table .= "<td>{$usuario[2]}</td>";
        $table .= "</tr>";
    }
    $table .= '</tbody>';
    $table .= '</table>';

    $conn->close();
    return $table;
}
function alterar_login($id, $nome, $senha){
    $conexao = new Conexao();

    $conn = $conexao->conectar();
    $sql = "UPDATE usuarios SET nome = ?, senha = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ssi", $nome, $senha, $id);
    $stmt->execute();
}