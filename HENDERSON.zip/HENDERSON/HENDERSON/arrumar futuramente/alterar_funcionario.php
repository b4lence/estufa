<?php
require "_connection/conexao.php";

function consultar_funcionario($nome){
    $conexao = new Conexao();
    if(empty($nome)){
        return;
    }
    $nome = '%'.$nome.'%';
    $conn = $conexao->conectar();
    $sql = "SELECT * FROM funcionarios WHERE nome LIKE ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $nome);
    $stmt->execute();

    $result = $stmt->get_result();
    $table = '<table>';
    $table .= '<thead>';
    $table .= '<tr>';
    $table .= '<td></td>';
    $table .= '<td>Nome</td>';
    $table .= '<td>Sobrenome</td>';
    $table .= '<td>E-mail</td>';
    $table .= '<td>CPF</td>';
    $table .= '<td>Telefone</td>';
    $table .= '<td>Endereço</td>';
    $table .= '<td>Data de Nascimento</td>';
    $table .= '<td>Genero</td>';
    $table .= '</tr>';
    $table .= '</thead>';
    
    $funcionarios = $result->fetch_all();

    $table .= '<tbody>';
    foreach($funcionarios as $funcionario){
        $table .= "<tr>";
        $table .= "<td><input type='radio' name='id' value='{$funcionario[0]}'></td>";
        $table .= "<td>{$funcionario[1]}</td>";
        $table .= "<td>{$funcionario[2]}</td>";
        $table .= "<td>{$funcionario[3]}</td>";
        $table .= "<td>{$funcionario[4]}</td>";
        $table .= "<td>{$funcionario[5]}</td>";
        $table .= "<td>{$funcionario[6]}</td>";
        $table .= "<td>{$funcionario[7]}</td>";
        $table .= "<td>{$funcionario[8]}</td>";
        $table .= "</tr>";
    }
    $table .= '</tbody>';
    $table .= '</table>';

    $conn->close();
    return $table;
}
function alterar_funcionario($id, $nome, $sobre, $email, $cpf, $telefone, $endereco, $nascimento, $genero){
    $conexao = new Conexao();

    $conn = $conexao->conectar();
    $sql = "UPDATE funcionarios SET nome = ?, sobrenome = ?, email = ?, cpf = ?, telefone = ?, endereco = ?, nascimento = ?, genero = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("ssssssssi", $nome, $sobre, $email, $cpf, $telefone, $endereco, $nascimento, $genero, $id);
    $stmt->execute();
}