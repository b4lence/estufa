<?php
session_start();
if (!isset($_SESSION['user'])){
	header('Location: cadlogin.php');
	exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="_css/clistyle.css">
    <link rel="shortcut icon" href="favicon.ico">
    <title>Cadastro - Cliente</title>
</head>

<body>
    <div class="container">
        <div class="form-image">
            <img src="_images/cadcli-animate.svg" alt="Animação de segurança">
        </div>
        <div class="form">
            <form action="_php/cad-clientes.php" method="post">
                <div class="form-header">
                    <div class="title">
                        <h1>Clientes</h1>
                    </div>
                </div>

                <div class="input-group">
                    <div class="section-title">
                        <h6>Informações pessoais</h6>
                    </div>
                    <div class="input-box">
                        <label for="firstname">Primeiro Nome</label>
                        <input id="firstname" type="text" name="firstname" placeholder="Digite seu primeiro nome"
                            required>
                    </div>

                    <div class="input-box">
                        <label for="email">E-mail</label>
                        <input id="email" type="email" name="email" placeholder="Digite seu e-mail" required>
                    </div>

                    <div class="input-box">
                        <label for="number">Telefone/Celular</label>
                        <input type="text" onkeydown="return apenasNumeros(event);" id="tell" name="tel" maxlength="15"
                            OnKeyPress="formatar('(##) #####-####',this)" placeholder="(##) #####-####">
                    </div>
                    <div class="section-title">
                        <h6>Informações da empresa</h6>
                    </div>
                    <div class="input-box">
                        <label for="enterprise">Nome da empresa</label>
                        <input id="enterprise" type="text" name="enterprise" placeholder="Digite o nome da empresa"
                            required>
                    </div>

                    <div class="input-box">
                        <label for="cnpj">CNPJ</label>
                        <input oninput="mascaracnpj(this)" type="text" name="cnpj" id="cnpj"
                            placeholder="xx.xxx.xxx/yyyy-zz" required>
                    </div>

                    <div class="input-box">
                        <label for="address">Endereço</label>
                        <input id="address" type="text" name="address" placeholder="Endereço da empresa" required>
                    </div>
                </div>
                <div class="continue-button">
                    <input type="submit" value="Cadastrar">
                </div>
            </form>
        </div>
    </div>
    <script src="_js/scriptcli.js"></script>
</body>

</html>