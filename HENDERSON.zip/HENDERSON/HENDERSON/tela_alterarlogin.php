<?php require "arrumar futuramente/alterar_login.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method='post'>
        <input type='text' name='nome_antigo'/>
        <input type='submit' value='Pesquisar' name='btn_pesquisar'/>
        <?php 
        if(array_key_exists('btn_pesquisar', $_POST)) {
            echo consultar_login($_POST['nome_antigo']);
        }
        if(array_key_exists('btn_alterar', $_POST)) {
            echo alterar_login($_POST['id'], $_POST['nome'], $_POST['senha']);
        }
        ?><br>
        <input type='text' name='nome' placeholder='Nome'/><br>
        <input type='text' name='senha' placeholder='Senha'/><br>
        <input type='submit' value='Selecionar' name='btn_alterar'/>
    </form>
</body>
</html>