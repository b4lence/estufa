const mascaraMoeda = (event) => {
  // Remove todos os caracteres que não são dígitos
  const onlyDigits = event.target.value
    .replace(/\D/g, "") // Mantém apenas dígitos
    .padStart(3, "0");  // Garante que sempre haverá pelo menos 3 dígitos

  // Insere o ponto decimal no lugar correto
  const digitsFloat = onlyDigits.slice(0, -2) + "." + onlyDigits.slice(-2);

  // Atualiza o valor formatado visualmente para o usuário
  event.target.value = maskCurrency(digitsFloat);

  // Atualiza o valor "real" no campo de preço (sem formatação para o backend)
  document.getElementById('preco').value = digitsFloat;
}

const maskCurrency = (valor, locale = 'pt-BR', currency = 'BRL') => {
  // Formata o valor como moeda BRL
  return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency
  }).format(valor);
}