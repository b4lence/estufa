
function formatar(mascara, documento) {//----> Telefone/Celular
    let i = documento.value.length;
    let saida = '#';
    let texto = mascara.substring(i);

    while (texto.substring(0, 1) != saida && texto.length) {
        documento.value += texto.substring(0, 1);
        i++;
        texto = mascara.substring(i);
    }
}
function apenasNumeros(event) {//----> Telefone/Celular
    const tecla = event.key;
    if (!/^[0-9]$/.test(tecla) && tecla !== 'Backspace') {
        event.preventDefault();
    }
}

function mascara(i) {//----> CPF

    var v = i.value;

    if (isNaN(v[v.length - 1])) {
        i.value = v.substring(0, v.length - 1);
        return;
    }

    i.setAttribute("maxlength", "14");
    if (v.length == 3 || v.length == 7) i.value += ".";
    if (v.length == 11) i.value += "-";

}

function preencherData() { //----> Data de nascimento
    const diaSelect = document.getElementById('dia');
    const mesSelect = document.getElementById('mes');
    const anoSelect = document.getElementById('ano');

    const hoje = new Date();
    const diaAtual = hoje.getDate();
    const mesAtual = hoje.getMonth();
    const anoAtual = hoje.getFullYear();

    for (let d = 1; d <= 31; d++) {
        const option = document.createElement('option');
        option.value = d;
        option.text = d;
        if (d === diaAtual) option.selected = true;
        diaSelect.appendChild(option);
    }

    const meses = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    for (let m = 0; m < meses.length; m++) {
        const option = document.createElement('option');
        option.value = m + 1;
        option.text = meses[m];
        if (m === mesAtual) option.selected = true;
        mesSelect.appendChild(option);
    }

    for (let a = anoAtual; a >= 1900; a--) {
        const option = document.createElement('option');
        option.value = a;
        option.text = a;
        anoSelect.appendChild(option);
    }
}

window.onload = preencherData;
