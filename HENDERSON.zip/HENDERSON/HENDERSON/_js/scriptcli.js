function formatar(mascara, documento) {//----> Telefone/Celular
    let i = documento.value.length;
    let saida = '#';
    let texto = mascara.substring(i);

    while (texto.substring(0, 1) != saida && texto.length) {
        documento.value += texto.substring(0, 1);
        i++;
        texto = mascara.substring(i);
    }
}
function apenasNumeros(event) {//----> Telefone/Celular
    const tecla = event.key;
    if (!/^[0-9]$/.test(tecla) && tecla !== 'Backspace') {
        event.preventDefault();
    }
}

function mascaracnpj(a) {//----> CNPJ

    var x = a.value;

    if (isNaN(x[x.length - 1])) {
        a.value = x.substring(0, x.length - 1);
        return;
    }

    a.setAttribute("maxlength", "18");
    if (x.length == 2 || x.length == 6) a.value += ".";
    if (x.length == 10) a.value += "/";
    if (x.length == 15) a.value += "-";

}