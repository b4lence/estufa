<?php
require "../_connection/conexao.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    $conexao = new Conexao();
    $conn = $conexao->conectar();

    if ($conn) {
        $nome = $_POST['firstname'];
        $sobrenome = $_POST['lastname'];
        $email = $_POST['email'];
        $cpf = $_POST['cpf'];
        $telefone = $_POST['tel'];
        $endereco = $_POST['endereco'];
        $data_nasc = $_POST['ano'] . '-' .  $_POST['mes'] . '-' . $_POST['dia'];
        $genero = $_POST['gender'];

        if (!empty($nome) && !empty($sobrenome) && !empty($email) && !empty($cpf) && !empty($telefone) && !empty($endereco) && !empty($data_nasc) && !empty($genero)) {
            $sql = "INSERT INTO funcionarios (nome, sobrenome, email, cpf, telefone, endereco, nascimento, genero) VALUES (?,?,?,?,?,?,?,?)";
            $stm = $conn->prepare($sql);
            if ($stm) {
                $stm->bind_param("ssssssss", $nome, $sobrenome, $email, $cpf, $telefone, $endereco, $data_nasc, $genero);
                if ($stm->execute()) {
                    echo
                    '<script>
                        alert("Registration completed");
                        window.location.href = "../index.php";
                    </script>';
                    exit();
                } else {
                    echo
                    '<script>
                        alert("Registration failed");
                        window.location.href = "../cadfunci.php";
                    </script>';
                    exit();
                }
            } else {
                echo
                '<script>
                    alert("Error in preparing the statement");
                    window.location.href = "../cadfunci.php";
                </script>' . $conn->error;
                exit();
            }
        } else {
            echo
            '<script>
                alert("Error: All fields are required.");
                window.location.href = "../cadfunci.php";
            </script>';
        }

        $conn->close();
    }
}