
<?php
session_start();
require '../_connection/conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['user'];
    $password = $_POST['password'];

    $conexao = new Conexao();
    $conn = $conexao->conectar();

    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE nome = ?");
    if ($stmt == false) {
        die('prepare() failed: '  . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($password == $user['senha']) {
            $_SESSION['user'] = $username;
            header('Location: ../index.php');
            exit();
        } else {
            echo 
            '<script>
                alert("Unable to connect to Dashboard");
                window.location.href = "../cadlogin.php";
            </script>';
            exit();
        }
    } else {
        echo 
        '<script>
            alert("Unable to connect to Dashboard");
            window.location.href = "../cadlogin.php";
        </script>';
        exit();
    }
}
?>


