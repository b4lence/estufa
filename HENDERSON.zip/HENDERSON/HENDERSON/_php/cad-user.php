<?php
require '../_connection/conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conexao = new Conexao();
    $conn = $conexao->conectar();

    if ($conn) {
        $new_username = $_POST['newuser'];
        $new_password = $_POST['newpassword'];

        if (!empty($new_username) && !empty($new_password)) {
            $sql = "INSERT INTO usuarios (nome, senha) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("ss", $new_username, $new_password);
                if ($stmt->execute()) {
                    echo
                    '<script>
                        alert("Registration completed");
                        window.location.href = "../index.php";
                    </script>';
                    exit();
                } else {
                    echo 
                    '<script>
                        alert("Registration failed");
                        window.location.href = "../caduser.php";
                    </script>';
                    exit();
                }
            } else {
                echo 
                '<script>
                    alert("Error in preparing the declaration");
                    window.location.href = "../caduser.php";
                </script>' . $conn->error;
                exit();
            }
        } else {
            echo 
            '<script>
                alert("Error: All fields are required.");
                window.location.href = "../caduser.php";
            </script>';
        }

        $conn->close();
    } 
}
