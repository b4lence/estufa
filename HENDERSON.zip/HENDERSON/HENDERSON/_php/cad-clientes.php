<?php
require '../_connection/conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conexao = new Conexao();
    $conn = $conexao->conectar();

    if ($conn) {
        $firstname = $_POST['firstname'];
        $email = $_POST['email'];
        $tell = $_POST['tel'];
        $entername = $_POST['enterprise'];
        $cnpj = $_POST['cnpj'];
        $address = $_POST['address'];

        if (!empty($firstname) && !empty($email)  && !empty($tell)  && !empty($entername)  && !empty($cnpj)  && !empty($address)) {
            $sql = "INSERT INTO clientes (nome, email, telefone, empresa, cnpj, endereco) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("ssssss", $firstname, $email, $tell, $entername, $cnpj, $address);
                if ($stmt->execute()) {
                    echo
                    '<script>
                        alert("Registration completed");
                        window.location.href = "../index.php";
                    </script>';
                    exit();
                } else {
                    echo 
                    '<script>
                        alert("Registration failed");
                        window.location.href = "../cadcli.php";
                    </script>';
                    exit();
                }
            } else {
                echo 
                '<script>
                    alert("Error in preparing the declaration");
                    window.location.href = "../cadcli.php";
                </script>' . $conn->error;
                exit();
            }
        } else {
            echo 
            '<script>
                alert("Error: All fields are required.");
                window.location.href = "../cadcli.php";
            </script>';
        }

        $conn->close();
    } 
}
?>
