<?php
require_once '../_connection/conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conexao = new Conexao();
    $conn = $conexao->conectar( );

    if ($conn) {
        $nomeprod = $_POST['nomeprod'];
        $qtd = $_POST['quantidade'];
        $unidade = $_POST['unidade'];
        $preco = $_POST['preco'];
        $descricao = $_POST['descricao'];

        if (!empty($preco)) {
            $preco = str_replace(['R$', ' '], '', $preco);
            $preco = floatval($preco);
        } else {
            echo "Erro: Preço não pode estar vazio.";
            exit;
        }
        if (!empty($nomeprod) && !empty($qtd) && !empty($unidade) && !empty($descricao)) {
            $sql = "INSERT INTO produtos (nome, estoque, unidade, preco, descr) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sisds", $nomeprod, $qtd, $unidade, $preco, $descricao);
                if ($stmt->execute()) {
                    echo 
                    '<script>
                        alert("Successfully inserted");
                        window.location.href = "../index.php";
                     </script>';
            exit();
                } else {
                    echo 
                    '<script>
                        alert("Insertion failure");
                        window.location.href = "../cadprod.php";
                    </script>';
                }
                $stmt->close();
            } else {
                echo 
                '<script>
                    alert("Error in preparing the declaration");
                    window.location.href = "../cadprod.php";
                </script>' . $conn->error;
                exit();
            }
        } else {
            echo 
            '<script>
                alert("Error: All fields are required.");
                window.location.href = "../cadprod.php";
            </script>';
        }
        $conn->close();
    }
}
?>
