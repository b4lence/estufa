<?php
session_start();
if (!isset($_SESSION['user'])){
	header('Location: cadlogin.php');
	exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="_css/userstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Cadastro - Usuário</title>
</head>

<body>
    <div class="container">
        <div class="form-image">
            <img src="_images/caduser-animate.svg" alt="Animação de segurança">
        </div>
        <div class="form">
            <form action="_php/cad-user.php" method="post">
                <div class="form-header">
                    <div class="title">
                        <h1>Usuario</h1>
                    </div>
                </div>

                <div class="input-group">
                    <div class="input-box">
                        <label for="newuser">Usuário</label>
                        <input id="newuser" type="text" name="newuser" placeholder="Insira um nome de usuário" required>
                    </div>

                    <div class="input-box">
                        <label for="newpassword">Senha</label>
                        <input id="newpassword" type="password" name="newpassword" placeholder="Insira uma senha" required>
                    </div>
                </div>
                <div class="continue-button">
                    <input type="submit" value="Entrar">
                </div>
            </form>
        </div>
    </div>
</body>

</html>
