<?php require "arrumar futuramente/alterar_produto.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method='post'>
        <input type='text' name='nome_antigo'/>
        <input type='submit' value='Pesquisar' name='btn_pesquisar'/>
        <?php 
        if(array_key_exists('btn_pesquisar', $_POST)) {
            echo consultar_produto($_POST['nome_antigo']);
        }
        if(array_key_exists('btn_alterar', $_POST)) {
            $preco = str_replace(',', '.', $_POST['preco']);
            echo alterar_produto($_POST['id'], $_POST['nome'], $_POST['descr'], $preco, $_POST['unidade'], $_POST['estoque']);
        }
        ?><br>
        <input type='text' name='nome' placeholder='Nome'/><br>
        <input type='text' name='descr' placeholder='Descrição'/><br>
        <input type='text' name='preco' placeholder='Preço'/><br>
        <input type='text' name='unidade' placeholder='Unidade'/><br>
        <input type='text' name='estoque' placeholder='Estoque'/><br>
        <input type='submit' value='Selecionar' name='btn_alterar'/>
    </form>
</body>
</html>