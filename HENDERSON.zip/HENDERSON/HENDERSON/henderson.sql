CREATE DATABASE henderson;

USE henderson;

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  senha VARCHAR(100) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE funcionarios (
  id int(11) AUTO_INCREMENT NOT NULL,
  nome varchar(50) NOT NULL,
  sobrenome varchar(50) NOT NULL,
  email varchar(100) NOT NULL,
  cpf varchar(14) NOT NULL,
  telefone varchar(15) NOT NULL,
  endereco varchar(200) NOT NULL,
  nascimento date NOT NULL,
  genero varchar(30),
  PRIMARY KEY (id)
);

CREATE TABLE clientes (
  id int(11) AUTO_INCREMENT NOT NULL,
  nome varchar(50) NOT NULL,
  sobrenome varchar(50) NOT NULL,
  email varchar(100) NOT NULL,
  cnpj varchar(18) NOT NULL,
  telefone varchar(15) NOT NULL,
  endereco varchar(200) NOT NULL,
  empresa varchar(100) NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE produtos (
  id int(11) AUTO_INCREMENT NOT NULL,
  nome varchar(100) NOT NULL,
  descr text NOT NULL,
  preco decimal(10,2) NOT NULL,
  estoque int(11) NOT NULL,
  unidade varchar(2) NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO clientes (`nome`, `sobrenome`, `email`, `cnpj`, `telefone`, `endereco`, `empresa`) VALUES
	('miguel', 'balanço', 'miguel@balanco.com.br', '123456', '11223344', 'la em casa', 'sou vagabundo');
INSERT INTO funcionarios (`nome`, `sobrenome`, `email`, `cpf`, `telefone`, `endereco`, `nascimento`, `genero`) VALUES
	('miguel', 'balanco', 'miguel@balanco.com.br', '546.798.123-45', '119879546', 'la em casa', '1996-05-05', 'miguel');
