<?php
session_start();
if (!isset($_SESSION['user'])){
	header('Location: cadlogin.php');
	exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="_css/funcstyle.css">
    <link rel="shortcut icon" href="favicon.ico">
    <title>Cadastro - Funcionario</title>
</head>

<body>
    <div class="container">
        <div class="form-image">
        <img src="_images/cadfunci-animate.svg" alt="Animação de segurança">
        </div>
        <div class="form">
            <form action="_php/cad-funcionario.php" method="post">
                <div class="form-header">
                    <div class="title">
                        <h1>Funcionario</h1>
                    </div>
                </div>

                <div class="input-group">
                    <div class="input-box">
                        <label for="firstname">Primeiro Nome</label>
                        <input id="firstname" type="text" name="firstname" placeholder="Digite seu primeiro nome"
                            required>
                    </div>

                    <div class="input-box">
                        <label for="lastname">Sobrenome</label>
                        <input id="lastname" type="text" name="lastname" placeholder="Digite seu sobrenome" required>
                    </div>
                    <div class="input-box">
                        <label for="email">E-mail</label>
                        <input id="email" type="email" name="email" placeholder="Digite seu e-mail" required>
                    </div>

                    <div class="input-box">
                        <label for="password">CPF</label>
                        <input oninput="mascara(this)" type="text" name="cpf" id="cpf" placeholder="xxx.xxx.xxx-xx"
                            required>
                    </div>

                    <div class="input-box">
                        <label for="number">Telefone/Celular</label>
                        <input type="text" onkeydown="return apenasNumeros(event);" id="tell" name="tel" maxlength="15" OnKeyPress="formatar('(##) #####-####',this)"
                            placeholder="(##) #####-####">
                    </div>

                    <div class="input-box">
                        <label for="endereco">Endereço</label>
                        <input id="endereco" type="text" name="endereco" placeholder="Endereço" required>
                    </div>


                </div>

                <div class="date-inputs">
                    <div class="date-title">
                        <h6>Date of birth</h6>
                    </div>

                    <div class="date-group">
                        <div class="date-input">
                            <select id="dia" name="dia"></select>
                        </div>

                        <div class="date-input">
                            <select id="mes" name="mes"></select>
                        </div>

                        <div class="date-input">
                            <select id="ano" name="ano"></select>
                        </div>
                    </div>
                </div>

                <div class="gender-inputs">
                    <div class="gender-title">
                        <h6>Gênero</h6>
                    </div>

                    <div class="gender-group">
                        <div class="gender-input">
                            <input id="female" type="radio" name="gender" value="Feminino"/>
                            <label for="female">Feminino</label>
                        </div>

                        <div class="gender-input">
                            <input id="male" type="radio" name="gender" value="Masculino"/>
                            <label for="male">Masculino</label>
                        </div>

                        <div class="gender-input">
                            <input id="others" type="radio" name="gender" value="Outros"/>
                            <label for="others">Outros</label>
                        </div>

                        <div class="gender-input">
                            <input id="none" type="radio" name="gender" value="Prefiro não dizer"/>
                            <label for="none">Prefiro não dizer</label>
                        </div>
                    </div>
                </div>

                <div class="continue-button">
                    <input type="submit" value="Entrar">
                </div>
            </form>
        </div>
    </div>
    <script src="_js/scriptfun.js"></script>
</body>

</html>