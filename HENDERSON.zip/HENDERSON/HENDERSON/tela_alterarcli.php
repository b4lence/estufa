<?php require "arrumar futuramente/alterar_cliente.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method='post'>
        <input type='text' name='nome_antigo'/>
        <input type='submit' value='Pesquisar' name='btn_pesquisar'/>
        <?php 
        if(array_key_exists('btn_pesquisar', $_POST)) {
            echo consultar_cliente($_POST['nome_antigo']);
        }
        if(array_key_exists('btn_alterar', $_POST)) {
            echo alterar_cliente($_POST['id'], $_POST['nome'], $_POST['sobre'], $_POST['email'], $_POST['cnpj'], $_POST['tel'], $_POST['endereco'], $_POST['empresa']);
        }
        ?><br>
        <input type='text' name='nome' placeholder='Nome'/><br>
        <input type='text' name='sobre' placeholder='Sobrenome'/><br>
        <input type='text' name='email' placeholder='E-mail'/><br>
        <input type='text' name='cnpj' placeholder='CNPJ'/><br>
        <input type='text' name='tel' placeholder='Telefone'/><br>
        <input type='text' name='endereco' placeholder='Endereco'/><br>
        <input type='text' name='empresa' placeholder='Empresa'/><br>
        <input type='submit' value='Selecionar' name='btn_alterar'/>
    </form>
</body>
</html>